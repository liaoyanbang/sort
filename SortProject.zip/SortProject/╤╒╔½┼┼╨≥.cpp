#include<stdio.h>
void swap(int* nums, int i, int j) ;
void sortColors(int* nums, int numsSize);
int main()
{
	int array[]={0,1,0,2,2,1,1,1,0,0,2,0,1,0,2,1,0,2,1,0,2,0,1,2,0,1,2,1,0,2,1,0};
	int leng=sizeof(array)/sizeof(array[0]);
	int i,j,k,temp;
	for(k=0;k<leng;k++)
	{
		printf("%d ",array[k]);
	}
	printf("\n");
	sortColors(array,leng);
	for(k=0;k<leng;k++)
	{
		printf("%d ",array[k]);
	}
	printf("\n");
	getchar();
	return 0;
	
}
void swap(int* nums, int i, int j) {
    int t = nums[i];
    nums[i] = nums[j];
    nums[j] = t;
}
void sortColors(int* nums, int numsSize) {
    int i = 0, j = 0, k = numsSize - 1;
    int t = 0;
    for(i = 0; i <= k; i++) {
        if(nums[i] == 0) {
            swap(nums, i, j);
            j++;
        }
        else if(nums[i] == 2) {
            swap(nums, i, k);
            k--;
            i--;
        }
    }
}

