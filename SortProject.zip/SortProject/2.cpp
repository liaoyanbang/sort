#include<stdio.h>
#include<time.h>
void swap(int a,int b);
int partition2(int A[], int start, int end);
int findKthNum(int A[], int N, int K);
int main()
{ 
	int i,ch;
	int a[]={11,156,12,3,88,64,12,1545,21,112,111,2234,55,11,0,3,5556,5151,77,99,22,33,0,11233,5};
	int leng=sizeof(a)/sizeof(a[0]);
	for(i=0;i<leng;i++)
	{
		printf("%d ",a[i]);
		
	}
	printf("\n");
	printf("����������õ��ĵڼ������:");
	scanf("%d",&ch);
	printf("%d",findKthNum(a,leng,ch));
	getchar();
	return 0;
} 
int partition2(int A[], int start, int end){

	//swap(A[start],A[rand()%(end -start)];
	int pivot = A[start];
	int ix = start; 

	int jx = start + 1;
	while (jx <= end){    
		if ( A[jx] > pivot ){ //���ƴ�����ǰ
			swap(A[jx], A[ix++]);
		}
		++jx;
	}
	A[ix] = pivot; 
	return ix;  
}
int findKthNum(int A[], int N, int K)
{
	int start=0;
	int end=N-1;
	int pos;
	while(1)
	{
		pos=partition2(A,start,end);
		if(pos==K-1)
		{	
			break;	 
		}
		 else if(pos>K-1)
		 {
		 	end=pos-1;
		 }
		 else {
		 	start=pos+1;
		 }
	}
	return A[pos];
}
void swap(int a,int b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
}
